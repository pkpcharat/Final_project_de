import streamlit as st
import pandas as pd
import sqlite3
import plotly.express as px
from plotly.colors import n_colors

# ===========================
# STREAMLIT CONFIG
# ===========================
st.set_page_config(page_title="Hospital Agent Dashboard", layout="wide", page_icon="🏥")
st.markdown(
    """
    <style>
    /* Dark background */
    .reportview-container {
        background-color: #1a1a1a;
        color: #f5f5f5;
    }
    .sidebar .sidebar-content {
        background-color: #111111;
        color: #f5f5f5;
    }
    .stMetricValue {
        color: #FFD700;
        font-weight: bold;
    }
    .stDataFrame th {
        color: #FFD700;
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.title("Hospital Agent Performance Dashboard")
st.markdown(" ", unsafe_allow_html=True)

# ===========================
# LOAD DATA
# ===========================
conn = sqlite3.connect("warehouse.db")
fact = pd.read_sql("SELECT * FROM fact_patient_activity_clean", conn)
agent = pd.read_sql("SELECT * FROM dim_agent", conn)
conn.close()

# แปลงวันที่/เดือนสำหรับ filter
fact["admit_date"] = pd.to_datetime(fact["admit_date"])
fact["year_month"] = fact["admit_date"].dt.to_period("M").dt.to_timestamp()

# ===========================
# SIDEBAR FILTERS
# ===========================
st.sidebar.header("Filters")
agents_list = fact["agent_name"].unique().tolist()
selected_agents = st.sidebar.multiselect("Select Agent(s)", agents_list, default=agents_list)

date_range = st.sidebar.date_input(
    "Admit Date Range",
    [fact["admit_date"].min(), fact["admit_date"].max()]
)

outcomes_list = fact["treatment_success"].unique().tolist()
selected_outcomes = st.sidebar.multiselect("Patient Outcome", outcomes_list, default=outcomes_list)

# Apply filters
df_filtered = fact[
    (fact["agent_name"].isin(selected_agents)) &
    (fact["admit_date"].between(pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1]))) &
    (fact["treatment_success"].isin(selected_outcomes))
]

# ===========================
# KPI Section
# ===========================
st.subheader(" Key Performance Indicators")
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Total Patients", len(df_filtered))

with col2:
    st.metric("Total Revenue", f"฿{df_filtered['treatment_cost'].sum():,.2f}")

with col3:
    st.metric("Avg Length of Stay (days)", round(df_filtered["stay_days"].mean(), 2))

with col4:
    success_rate_overall = df_filtered["treatment_success"].mean() * 100
    st.metric("Overall Success Rate (%)", f"{success_rate_overall:.2f}%")

st.markdown("---")

# ===========================
# Agent Ranking
# ===========================
st.subheader(" Agent Ranking by Revenue / Success Rate")

ranking = (
    df_filtered.groupby(["agent_id", "agent_name"])
    .agg(
        total_revenue=("treatment_cost", "sum"),
        patients=("patient_id", "count"),
        success_rate=("treatment_success", "mean")
    )
    .reset_index()
)
ranking["Success Rate (%)"] = (ranking["success_rate"] * 100).round(2)
ranking = ranking.sort_values("total_revenue", ascending=False)

st.dataframe(ranking[["agent_name", "patients", "total_revenue", "Success Rate (%)"]])

# ===========================
# Revenue per Agent Bar Chart
# ===========================
fig_rank = px.bar(
    ranking,
    x="agent_name",
    y="total_revenue",
    color="Success Rate (%)",
    text="Success Rate (%)",
    title="Agent Revenue Ranking with Success Rate",
    color_continuous_scale=px.colors.sequential.Teal,
    hover_data={"total_revenue":":,.2f"}
)
fig_rank.update_traces(
    hovertemplate='Agent: %{x}<br>Total Revenue: ฿%{y:,.2f}<br>Success Rate: %{customdata[0]}%'
)
fig_rank.update_layout(
    yaxis_title="Total Revenue (฿)", xaxis_title="Agent",
    plot_bgcolor='#1a1a1a', paper_bgcolor='#1a1a1a',
    font_color="#f5f5f5"
)
st.plotly_chart(fig_rank, use_container_width=True)

# ===========================
# Success Rate per Agent Bar Chart
# ===========================
st.subheader(" Success Rate per Agent")

fig_success = px.bar(
    ranking,
    x="agent_name",
    y="Success Rate (%)",
    text="Success Rate (%)",
    color="Success Rate (%)",
    color_continuous_scale=px.colors.sequential.Viridis,
    title="Success Rate by Agent (%)"
)
fig_success.update_layout(
    yaxis_title="Success Rate (%)", xaxis_title="Agent",
    plot_bgcolor='#1a1a1a', paper_bgcolor='#1a1a1a',
    font_color="#f5f5f5"
)
st.plotly_chart(fig_success, use_container_width=True)

# ===========================
# Success / Fail Stacked Bar per Agent
# ===========================
st.subheader(" Success vs Fail Patients per Agent")

stacked = (
    df_filtered.groupby(["agent_name", "treatment_success"])
    .size()
    .reset_index(name="count")
)

fig_stacked = px.bar(
    stacked,
    x="agent_name",
    y="count",
    color="treatment_success",
    text="count",
    title="Number of Success vs Fail Patients per Agent",
    color_discrete_map={"success": "green", "fail": "red"}
)
fig_stacked.update_layout(
    yaxis_title="Number of Patients",
    xaxis_title="Agent",
    barmode="stack",
    plot_bgcolor='#1a1a1a', paper_bgcolor='#1a1a1a',
    font_color="#f5f5f5"
)
st.plotly_chart(fig_stacked, use_container_width=True)

# ===========================
# Monthly Revenue Trend (per Agent)
# ===========================
st.subheader(" Monthly Treatment Revenue Trend")

month_trend = df_filtered.groupby(["year_month", "agent_name"])["treatment_cost"].sum().reset_index()
fig_month = px.line(
    month_trend,
    x="year_month",
    y="treatment_cost",
    color="agent_name",
    markers=True,
    title="Monthly Revenue Trend per Agent",
    hover_data={"treatment_cost":":,.2f"}
)
fig_month.update_traces(
    hovertemplate='Month: %{x|%b %Y}<br>Revenue: ฿%{y:,.2f}<br>Agent: %{legendgroup}'
)
fig_month.update_layout(
    yaxis_title="Revenue (฿)", xaxis_title="Month",
    plot_bgcolor='#1a1a1a', paper_bgcolor='#1a1a1a',
    font_color="#f5f5f5"
)
st.plotly_chart(fig_month, use_container_width=True)

# ===========================
# Interactive Table
# ===========================
st.subheader(" Explore Filtered Fact Data")
st.dataframe(df_filtered.sort_values(by="admit_date", ascending=False))

# ===========================
# Export Filtered Data
# ===========================
st.subheader("Export Filtered Data")

def convert_df(df):
    return df.to_csv(index=False).encode('utf-8')

csv = convert_df(df_filtered)

st.download_button(
    label="Download Filtered Data as CSV",
    data=csv,
    file_name='filtered_fact_data.csv',
    mime='text/csv'
)
