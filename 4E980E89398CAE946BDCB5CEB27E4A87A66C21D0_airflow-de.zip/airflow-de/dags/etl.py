# etl.py
import pandas as pd
import sqlite3

def load_data(db_path="/content/warehouse.db"):
    """Load data from SQLite"""
    conn = sqlite3.connect(db_path)
    fact = pd.read_sql("SELECT * FROM fact_patient_activity_clean", conn)
    agent = pd.read_sql("SELECT * FROM dim_agent", conn)
    conn.close()
    return fact, agent

def clean_transform_data(fact: pd.DataFrame):
    """Perform cleaning and transformation on fact table"""
    # Convert dates
    fact["admit_date"] = pd.to_datetime(fact["admit_date"], errors='coerce')
    fact["discharge_date"] = pd.to_datetime(fact["discharge_date"], errors='coerce')

    # Handle missing values
    fact['treatment_cost'] = fact['treatment_cost'].fillna(0)
    fact['stay_days'] = (fact['discharge_date'] - fact['admit_date']).dt.days.fillna(0)

    # Handle duplicates
    fact = fact.drop_duplicates()

    # Filter out impossible values
    fact = fact[fact['stay_days'] >= 0]

    # Year-month column for trends
    fact["year_month"] = fact["admit_date"].dt.to_period("M").dt.to_timestamp()

    return fact

def filter_data(fact: pd.DataFrame, agents=None, outcomes=None, date_range=None):
    """Filter data according to sidebar inputs"""
    df = fact.copy()
    if agents:
        df = df[df["agent_name"].isin(agents)]
    if outcomes:
        df = df[df["treatment_success"].isin(outcomes)]
    if date_range:
        df = df[df["admit_date"].between(pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1]))]
    return df
