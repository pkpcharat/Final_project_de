from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from etl import load_data, clean_transform_data

import pandas as pd

def etl_pipeline():
    # Load data
    fact, agent = load_data()
    # Clean & transform
    fact = clean_transform_data(fact)
    # Save processed data
    fact.to_csv("/opt/airflow/data/processed_agent_data.csv", index=False)
    print("ETL pipeline completed. Processed data saved.")

default_args = {
    "start_date": datetime(2024, 1, 1)
}

with DAG(
    dag_id="hospital_agent_pipeline",
    default_args=default_args,
    schedule_interval=None,  # or '@daily' if you want automatic runs
    catchup=False
) as dag:

    run_etl = PythonOperator(
        task_id="run_etl_pipeline",
        python_callable=etl_pipeline
    )

    run_etl
